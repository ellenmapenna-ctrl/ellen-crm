// Migra os dados reais do Painel de Atenção standalone (dados.json) para as
// tabelas rotina_* no Supabase. Rodar uma única vez.
import pg from "pg";
import { readFileSync } from "node:fs";

const dados = JSON.parse(readFileSync("/Users/adm/Painel-Atencao/dados.json", "utf-8"));

const client = new pg.Client({
  host: "aws-0-sa-east-1.pooler.supabase.com",
  port: 6543,
  user: `postgres.${process.env.SB_REF}`,
  password: process.env.SB_DB_PASSWORD,
  database: "postgres",
  ssl: { rejectUnauthorized: false },
});

await client.connect();

for (const n of dados.negocios) {
  await client.query(
    `insert into rotina_negocios (id, nome, tipo, pai_id, retorno, dependencia, atencao_alvo_pct, cor, ativo, projeto_total_apolices, projeto_apolices_migradas, projeto_data_alvo)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
     on conflict (id) do nothing`,
    [
      n.id, n.nome, n.tipo, n.paiId, n.retorno, n.dependencia, n.atencaoAlvoPct ?? null, n.cor, n.ativo,
      n.projeto?.totalApolices ?? null, n.projeto?.apolicesMigradas ?? null, n.projeto?.dataAlvo ?? null,
    ]
  );
}

for (const g of dados.gargalos) {
  await client.query(
    `insert into rotina_gargalos (id, negocio_id, descricao, aberto_em, resolvido_em, status)
     values ($1,$2,$3,$4,$5,$6) on conflict (id) do nothing`,
    [g.id, g.negocioId, g.descricao, g.abertoEm, g.resolvidoEm, g.status]
  );
}

for (const a of dados.acoes) {
  await client.query(
    `insert into rotina_acoes (id, gargalo_id, descricao, dono, prazo, concluida_em)
     values ($1,$2,$3,$4,$5,$6) on conflict (id) do nothing`,
    [a.id, a.gargaloId, a.descricao, a.dono, a.prazo, a.concluidaEm]
  );
  for (const p of a.passos ?? []) {
    await client.query(
      `insert into rotina_passos (id, acao_id, descricao, concluido_em)
       values ($1,$2,$3,$4) on conflict (id) do nothing`,
      [p.id, a.id, p.descricao, p.concluidoEm]
    );
  }
}

for (const r of dados.registros ?? []) {
  await client.query(
    `insert into rotina_registros (id, negocio_id, data, horas)
     values ($1,$2,$3,$4) on conflict (id) do nothing`,
    [r.id, r.negocioId, r.data, r.horas]
  );
}

for (const nt of dados.notas ?? []) {
  await client.query(
    `insert into rotina_notas (id, data, texto) values ($1,$2,$3) on conflict (id) do nothing`,
    [nt.id, nt.data, nt.texto]
  );
}

for (const s of dados.semanas ?? []) {
  await client.query(
    `insert into rotina_semanas (id, inicio, fechada, observacoes) values ($1,$2,$3,$4) on conflict (id) do nothing`,
    [s.id, s.inicio, s.fechada, s.observacoes]
  );
}

for (const r of dados.radar ?? []) {
  await client.query(
    `insert into rotina_radar (id, negocio_id, texto, criado_em, concluido_em) values ($1,$2,$3,$4,$5) on conflict (id) do nothing`,
    [r.id, r.negocioId, r.texto, r.criadoEm, r.concluidoEm]
  );
}

console.log("Dados migrados.");
await client.end();
