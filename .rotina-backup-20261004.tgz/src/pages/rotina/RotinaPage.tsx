import { PageHeader } from "@/components/shared/PageHeader";
import { LoadingState, ErrorState } from "@/components/shared/Feedback";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useRotinaEstado } from "@/hooks/useRotina";
import { AbaHoje } from "@/pages/rotina/AbaHoje";
import { AbaVisaoGeral } from "@/pages/rotina/AbaVisaoGeral";
import { AbaSemana } from "@/pages/rotina/AbaSemana";
import { AbaPortfolio } from "@/pages/rotina/AbaPortfolio";
import { AbaHistorico } from "@/pages/rotina/AbaHistorico";

export function RotinaPage() {
  const { data: estado, isLoading, isError, refetch } = useRotinaEstado();

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader
        title="Rotina & Gargalo"
        description="Gestão por gargalos entre os negócios — MPG, Seguro de Vida - MP e SPENA."
      />

      {isLoading && <LoadingState className="py-16" />}
      {isError && <ErrorState onRetry={() => refetch()} message="Não foi possível carregar o painel." />}

      {estado && (
        <Tabs defaultValue="hoje">
          <TabsList className="mb-4 flex-wrap">
            <TabsTrigger value="hoje">Hoje</TabsTrigger>
            <TabsTrigger value="visao">Visão Geral</TabsTrigger>
            <TabsTrigger value="semana">Semana</TabsTrigger>
            <TabsTrigger value="portfolio">Portfólio</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
          </TabsList>
          <TabsContent value="hoje"><AbaHoje estado={estado} /></TabsContent>
          <TabsContent value="visao"><AbaVisaoGeral estado={estado} /></TabsContent>
          <TabsContent value="semana"><AbaSemana estado={estado} /></TabsContent>
          <TabsContent value="portfolio"><AbaPortfolio estado={estado} /></TabsContent>
          <TabsContent value="historico"><AbaHistorico estado={estado} /></TabsContent>
        </Tabs>
      )}
    </div>
  );
}
