import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  addDias,
  diasEntre,
  fmtBR,
  horasNoIntervalo,
  inicioSemana,
  negocioPorId,
  negociosComCota,
  realPct,
} from "@/lib/rotina";
import { hojeIso } from "@/lib/sitplan";
import type { RotinaEstado } from "@/lib/types";

export function AbaHistorico({ estado }: { estado: RotinaEstado }) {
  const hoje = hojeIso();
  const cota = negociosComCota(estado);
  const semanasSet = new Set<string>();
  estado.registros.forEach((r) => semanasSet.add(inicioSemana(r.data)));
  estado.semanas.forEach((s) => semanasSet.add(s.inicio));
  semanasSet.add(inicioSemana(hoje));
  const semanasList = [...semanasSet].sort().reverse();

  const resolvidos = estado.gargalos.filter((g) => g.status === "resolvido").length;
  const arrastados = estado.gargalos.filter((g) => g.status === "aberto" && diasEntre(g.aberto_em, hoje) >= 21).length;

  const gargalosOrdenados = [...estado.gargalos].sort((a, b) => b.aberto_em.localeCompare(a.aberto_em));

  const radarTodos = estado.radar ?? [];
  const radarResolvidos = radarTodos.filter((r) => r.concluido_em).length;
  const radarOrdenado = [...radarTodos].sort((a, b) => b.criado_em.localeCompare(a.criado_em));

  const notasOrdenadas = [...estado.notas].sort((a, b) => b.data.localeCompare(a.data));

  const exportar = () => {
    const blob = new Blob([JSON.stringify(estado, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `rotina-gargalo-${hoje}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-4">
      <Card className="p-4">
        <h2 className="mb-3 text-base font-semibold">Horas por semana</h2>
        {semanasList.length === 0 ? (
          <p className="text-sm text-muted-foreground">Sem registros ainda.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Semana</TableHead>
                  {cota.map((n) => <TableHead key={n.id}>{n.nome}</TableHead>)}
                </TableRow>
              </TableHeader>
              <TableBody>
                {semanasList.map((ini) => {
                  const fim = addDias(ini, 6);
                  return (
                    <TableRow key={ini}>
                      <TableCell>{fmtBR(ini)}–{fmtBR(fim)}</TableCell>
                      {cota.map((n) => {
                        const horas = horasNoIntervalo(estado, n.id, ini, fim);
                        const real = realPct(estado, n.id, ini, fim);
                        return <TableCell key={n.id}>{horas.toFixed(1)}h ({real.toFixed(0)}%)</TableCell>;
                      })}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      <Card className="p-4">
        <h2 className="mb-1 text-base font-semibold">Gargalos</h2>
        <p className="mb-3 text-xs text-muted-foreground">{resolvidos} resolvidos · {arrastados} arrastados (abertos há 21+ dias)</p>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Negócio</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Aberto</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duração</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {gargalosOrdenados.map((g) => {
                const n = negocioPorId(estado, g.negocio_id);
                const fim = g.resolvido_em || hoje;
                return (
                  <TableRow key={g.id}>
                    <TableCell>{n?.nome ?? "?"}</TableCell>
                    <TableCell className="max-w-xs">{g.descricao}</TableCell>
                    <TableCell>{fmtBR(g.aberto_em)}</TableCell>
                    <TableCell><Badge variant="outline">{g.status}</Badge></TableCell>
                    <TableCell>{diasEntre(g.aberto_em, fim)}d</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>

      <Card className="p-4">
        <h2 className="mb-1 text-base font-semibold">Radar</h2>
        <p className="mb-3 text-xs text-muted-foreground">
          {radarTodos.length ? `${radarResolvidos} concluídos · ${radarTodos.length - radarResolvidos} em aberto` : "Nada capturado ainda."}
        </p>
        <ul className="flex flex-col divide-y text-sm">
          {radarOrdenado.length === 0 && <li className="text-muted-foreground">Nada capturado ainda.</li>}
          {radarOrdenado.map((r) => {
            const n = r.negocio_id ? negocioPorId(estado, r.negocio_id) : null;
            return (
              <li key={r.id} className="py-1.5">
                <span className="mr-2 text-xs text-muted-foreground">{fmtBR(r.criado_em)}</span>
                {r.texto}
                {n && ` · ${n.nome}`}
                {r.concluido_em && <Badge variant="outline" className="ml-1.5">concluído</Badge>}
              </li>
            );
          })}
        </ul>
      </Card>

      <Card className="p-4">
        <h2 className="mb-3 text-base font-semibold">O que puxou sua atenção</h2>
        <ul className="flex flex-col divide-y text-sm">
          {notasOrdenadas.length === 0 && <li className="text-muted-foreground">Nada registrado ainda.</li>}
          {notasOrdenadas.map((n) => (
            <li key={n.id} className="py-1.5"><span className="mr-2 text-xs text-muted-foreground">{fmtBR(n.data)}</span>{n.texto}</li>
          ))}
        </ul>
      </Card>

      <Button type="button" variant="outline" className="self-start" onClick={exportar}>Exportar JSON</Button>
    </div>
  );
}
