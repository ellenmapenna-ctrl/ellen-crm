import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PassosChecklist } from "@/components/rotina/PassosChecklist";
import { BarraAlocacao } from "@/components/rotina/BarraAlocacao";
import {
  acaoAtivaDoGargalo,
  calcularAvisos,
  diasEntre,
  gargaloAberto,
  negociosAtivos,
  negociosComCota,
} from "@/lib/rotina";
import { hojeIso } from "@/lib/sitplan";
import {
  useAdicionarNota,
  useAdicionarRadar,
  useConcluirAcao,
  useConcluirRadar,
  useRegistrarHoras,
  useRemoverRadar,
} from "@/hooks/useRotina";
import type { RotinaEstado } from "@/lib/types";

export function AbaHoje({ estado }: { estado: RotinaEstado }) {
  const avisos = calcularAvisos(estado);
  const hoje = hojeIso();
  const negocios = negociosAtivos(estado);
  const cota = negociosComCota(estado);
  const notasHoje = estado.notas.filter((n) => n.data === hoje);
  const radarAbertosLista = (estado.radar ?? []).filter((r) => !r.concluido_em);

  const concluirAcao = useConcluirAcao();
  const registrarHoras = useRegistrarHoras();
  const adicionarNota = useAdicionarNota();
  const adicionarRadar = useAdicionarRadar();
  const concluirRadar = useConcluirRadar();
  const removerRadar = useRemoverRadar();

  const [nota, setNota] = useState("");
  const [radarTexto, setRadarTexto] = useState("");
  const [radarNegocio, setRadarNegocio] = useState<string>("__geral__");

  return (
    <div className="flex flex-col gap-4">
      <BarraAlocacao estado={estado} />

      {avisos.length > 0 && (
        <div className="flex flex-col gap-2">
          {avisos.map((a, i) => (
            <div
              key={i}
              className={
                a.tipo === "critico"
                  ? "rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
                  : "rounded-md border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400"
              }
            >
              {a.texto}
            </div>
          ))}
        </div>
      )}

      <Card className="p-4">
        <h2 className="mb-3 text-base font-semibold">Ações da semana</h2>
        {negocios.every((n) => !gargaloAberto(estado, n.id)) && (
          <p className="text-sm text-muted-foreground">Nenhum gargalo aberto.</p>
        )}
        <div className="flex flex-col divide-y">
          {negocios.map((n) => {
            const g = gargaloAberto(estado, n.id);
            if (!g) return null;
            const a = acaoAtivaDoGargalo(estado, g.id);
            const dias = diasEntre(g.aberto_em, hoje);
            return (
              <div key={n.id} className="flex items-start gap-2.5 py-2.5">
                {a && (
                  <Checkbox
                    className="mt-1"
                    checked={false}
                    onCheckedChange={() => concluirAcao.mutate(a.id)}
                    aria-label={`Concluir ação de ${n.nome}`}
                  />
                )}
                <div className="flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="size-2 shrink-0 rounded-full" style={{ background: n.cor }} />
                    <strong className="text-sm">{n.nome}</strong>
                    {dias >= 21 && <Badge variant="outline" className="border-destructive text-destructive">{dias} dias aberto</Badge>}
                  </div>
                  {a ? (
                    <>
                      <div className="mt-1 text-sm">{a.descricao}</div>
                      <div className="mt-0.5 text-xs text-muted-foreground">dono: {a.dono} · prazo: {a.prazo ? new Date(a.prazo + "T00:00:00").toLocaleDateString("pt-BR") : "—"}</div>
                      <PassosChecklist acaoId={a.id} passos={a.passos} />
                    </>
                  ) : (
                    <p className="mt-1 text-sm text-muted-foreground">Gargalo sem próxima ação definida. Defina na aba Semana.</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {cota.length > 0 && (
        <Card className="p-4">
          <h2 className="mb-3 text-base font-semibold">Horas de hoje</h2>
          <div className="flex flex-col gap-2">
            {cota.map((n) => {
              const reg = estado.registros.find((r) => r.negocio_id === n.id && r.data === hoje);
              return (
                <div key={n.id} className="flex items-center gap-3">
                  <div className="flex flex-1 items-center gap-1.5 text-sm">
                    <span className="size-2 shrink-0 rounded-full" style={{ background: n.cor }} />
                    {n.nome}
                  </div>
                  <Input
                    type="number"
                    step="0.25"
                    min={0}
                    className="w-28"
                    defaultValue={reg?.horas ?? ""}
                    placeholder="0"
                    onBlur={(e) => {
                      const v = e.target.value === "" ? null : parseFloat(e.target.value);
                      registrarHoras.mutate({ negocioId: n.id, data: hoje, horas: v, registroExistenteId: reg?.id ?? null });
                    }}
                  />
                </div>
              );
            })}
          </div>
        </Card>
      )}

      <Card className="p-4">
        <h2 className="mb-2 text-base font-semibold">Surgiu essa semana</h2>
        <p className="mb-3 text-xs text-muted-foreground">
          Captura rápida do que aparece fora do planejado. Quando algo aqui virar prioridade de verdade, promova pra ação de um gargalo na Semana.
        </p>
        <div className="flex flex-col divide-y">
          {radarAbertosLista.length === 0 && <p className="py-2 text-sm text-muted-foreground">Nada no radar agora.</p>}
          {radarAbertosLista.map((r) => {
            const n = r.negocio_id ? estado.negocios.find((x) => x.id === r.negocio_id) : null;
            return (
              <div key={r.id} className="flex items-center gap-2.5 py-2">
                <Checkbox checked={false} onCheckedChange={() => concluirRadar.mutate(r.id)} aria-label="Concluir item do radar" />
                <span className="flex-1 text-sm">{r.texto}</span>
                {n && (
                  <Badge variant="outline" className="gap-1.5">
                    <span className="size-1.5 rounded-full" style={{ background: n.cor }} />
                    {n.nome}
                  </Badge>
                )}
                <button type="button" className="text-muted-foreground hover:text-destructive" onClick={() => removerRadar.mutate(r.id)} aria-label="Remover item">×</button>
              </div>
            );
          })}
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Input
            value={radarTexto}
            onChange={(e) => setRadarTexto(e.target.value)}
            placeholder="O que surgiu?"
            className="min-w-40 flex-1"
          />
          <Select value={radarNegocio} onValueChange={setRadarNegocio}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__geral__">Geral</SelectItem>
              {negocios.map((n) => <SelectItem key={n.id} value={n.id}>{n.nome}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              if (!radarTexto.trim()) return;
              adicionarRadar.mutate({ texto: radarTexto.trim(), negocioId: radarNegocio === "__geral__" ? null : radarNegocio });
              setRadarTexto("");
            }}
          >
            Adicionar
          </Button>
        </div>
      </Card>

      <Card className="p-4">
        <h2 className="mb-2 text-base font-semibold">O que puxou sua atenção hoje</h2>
        <Textarea
          value={nota}
          onChange={(e) => setNota(e.target.value)}
          placeholder="Ex.: liguei 40min para resolver um problema de cartório que não era meu."
          rows={3}
        />
        <Button
          type="button"
          className="mt-2"
          onClick={() => {
            if (!nota.trim()) return;
            adicionarNota.mutate(nota.trim());
            setNota("");
          }}
        >
          Registrar
        </Button>
        {notasHoje.length > 0 && (
          <ul className="mt-3 flex flex-col gap-1.5 text-sm">
            {notasHoje.map((n) => <li key={n.id} className="border-b pb-1.5 last:border-0">{n.texto}</li>)}
          </ul>
        )}
      </Card>
    </div>
  );
}
