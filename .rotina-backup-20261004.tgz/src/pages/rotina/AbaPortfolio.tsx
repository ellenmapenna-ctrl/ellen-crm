import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Field } from "@/components/shared/Field";
import { QUADRANTES, negociosAtivos, negociosComCota, quadranteDe, type Quadrante } from "@/lib/rotina";
import { useAtualizarNegocio } from "@/hooks/useRotina";
import type { RotinaEstado } from "@/lib/types";

const ORDEM: Quadrante[] = ["motor", "armadilha", "piloto", "dreno"];

export function AbaPortfolio({ estado }: { estado: RotinaEstado }) {
  const negociosTopo = negociosAtivos(estado).filter((n) => n.tipo === "negocio");
  const atualizar = useAtualizarNegocio();

  const porQuadrante: Record<Quadrante, typeof negociosTopo> = { motor: [], armadilha: [], piloto: [], dreno: [] };
  negociosTopo.forEach((n) => porQuadrante[quadranteDe(n)].push(n));

  const cota = negociosComCota(estado);
  const soma = cota.reduce((s, n) => s + (n.atencao_alvo_pct || 0), 0);

  return (
    <div className="flex flex-col gap-4">
      <Card className="p-4">
        <h2 className="mb-1 text-base font-semibold">Matriz de alocação</h2>
        <p className="mb-3 text-center text-xs text-muted-foreground">↑ retorno potencial · dependência de mim →</p>
        <div className="grid grid-cols-1 gap-0.5 overflow-hidden rounded-lg border bg-border sm:grid-cols-2">
          {ORDEM.map((q) => (
            <div key={q} className="flex min-h-36 flex-col bg-card p-3">
              <h4 className="text-sm font-semibold">{QUADRANTES[q].titulo}</h4>
              <div className="mb-2 text-xs text-muted-foreground">{QUADRANTES[q].desc}</div>
              <div className="flex flex-1 flex-col gap-1.5">
                {porQuadrante[q].map((n) => (
                  <div key={n.id} className="rounded-md border bg-muted/40 px-2.5 py-1.5 text-sm" style={{ borderLeft: `4px solid ${n.cor}` }}>
                    <span className="flex items-center gap-1.5"><span className="size-2 rounded-full" style={{ background: n.cor }} /><strong>{n.nome}</strong></span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4">
        <h2 className="mb-3 text-base font-semibold">Atenção-alvo (%)</h2>
        {soma !== 100 && (
          <div className="mb-3 rounded-md border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400">
            Soma atual: {soma}%. Ajuste para fechar 100%.
          </div>
        )}
        <div className="flex flex-col gap-3">
          {negociosTopo.map((n) => (
            <Card key={n.id} className="p-3.5" style={{ borderLeft: `4px solid ${n.cor}` }}>
              <h3 className="mb-2 text-sm font-semibold">{n.nome}</h3>
              <div className="flex flex-wrap gap-2.5">
                <Field label="Retorno potencial" className="min-w-32 flex-1">
                  <Select value={n.retorno} onValueChange={(v) => atualizar.mutate({ id: n.id, campos: { retorno: v } })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="alto">Alto</SelectItem>
                      <SelectItem value="baixo">Baixo</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field label="Dependência de mim" className="min-w-40 flex-1">
                  <Select value={n.dependencia} onValueChange={(v) => atualizar.mutate({ id: n.id, campos: { dependencia: v } })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="alta">Depende de mim</SelectItem>
                      <SelectItem value="baixa">Roda sem mim</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                {n.atencao_alvo_pct !== null && (
                  <Field label="Atenção-alvo (%)" className="w-28">
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      defaultValue={n.atencao_alvo_pct}
                      onBlur={(e) => atualizar.mutate({ id: n.id, campos: { atencao_alvo_pct: parseFloat(e.target.value) || 0 } })}
                    />
                  </Field>
                )}
                <Field label="Cor" className="w-20">
                  <Input
                    type="color"
                    defaultValue={n.cor}
                    className="h-9 p-1"
                    onBlur={(e) => atualizar.mutate({ id: n.id, campos: { cor: e.target.value } })}
                  />
                </Field>
              </div>

              {n.projeto_total_apolices !== null && (
                <div className="mt-3">
                  <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Projeto de migração da carteira</span>
                  <Progress value={n.projeto_total_apolices! > 0 ? Math.min(100, ((n.projeto_apolices_migradas ?? 0) / n.projeto_total_apolices!) * 100) : 0} className="my-1.5 h-2.5" />
                  <div className="text-xs text-muted-foreground">
                    {n.projeto_apolices_migradas ?? 0} de {n.projeto_total_apolices} apólices migradas (
                    {(n.projeto_total_apolices! > 0 ? ((n.projeto_apolices_migradas ?? 0) / n.projeto_total_apolices!) * 100 : 0).toFixed(0)}%)
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2.5">
                    <Field label="Total de apólices" className="w-32">
                      <Input type="number" min={0} defaultValue={n.projeto_total_apolices ?? 0} onBlur={(e) => atualizar.mutate({ id: n.id, campos: { projeto_total_apolices: parseInt(e.target.value, 10) || 0 } })} />
                    </Field>
                    <Field label="Migradas" className="w-32">
                      <Input type="number" min={0} defaultValue={n.projeto_apolices_migradas ?? 0} onBlur={(e) => atualizar.mutate({ id: n.id, campos: { projeto_apolices_migradas: parseInt(e.target.value, 10) || 0 } })} />
                    </Field>
                    <Field label="Data-alvo" className="w-40">
                      <Input type="date" defaultValue={n.projeto_data_alvo ?? ""} onBlur={(e) => atualizar.mutate({ id: n.id, campos: { projeto_data_alvo: e.target.value || null } })} />
                    </Field>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      </Card>
    </div>
  );
}
