import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Field } from "@/components/shared/Field";
import { PassosChecklist } from "@/components/rotina/PassosChecklist";
import {
  acaoAtivaDoGargalo,
  diasEntre,
  fimSemana,
  fmtBR,
  gargaloAberto,
  horasNoIntervalo,
  inicioSemana,
  negociosAtivos,
  negociosComCota,
  realPct,
} from "@/lib/rotina";
import { hojeIso } from "@/lib/sitplan";
import { useAbrirGargalo, useAtualizarAcao, useDefinirAcao, useFecharSemana } from "@/hooks/useRotina";
import type { RotinaAcaoComPassos, RotinaEstado, RotinaGargalo, RotinaNegocio } from "@/lib/types";

function CardNegocio({ estado, negocio }: { estado: RotinaEstado; negocio: RotinaNegocio }) {
  const g = gargaloAberto(estado, negocio.id);
  const a = g ? acaoAtivaDoGargalo(estado, g.id) : undefined;
  const abrirGargalo = useAbrirGargalo();
  const definirAcao = useDefinirAcao();
  const atualizarAcao = useAtualizarAcao();

  const [novoGargalo, setNovoGargalo] = useState("");
  const [novaAcaoDesc, setNovaAcaoDesc] = useState("");
  const [dono, setDono] = useState(a?.dono ?? "Ellen");
  const [prazo, setPrazo] = useState(a?.prazo ?? "");

  const dias = g ? diasEntre(g.aberto_em, hojeIso()) : 0;

  const handleAbrirNovo = async () => {
    if (!novoGargalo.trim()) return;
    const novo = await abrirGargalo.mutateAsync({ negocioId: negocio.id, descricao: novoGargalo.trim() });
    if (novaAcaoDesc.trim()) {
      await definirAcao.mutateAsync({ gargaloId: novo.id, descricao: novaAcaoDesc.trim(), dono: "Ellen", prazo: null });
    }
    setNovoGargalo("");
    setNovaAcaoDesc("");
  };

  const handleTrocar = async () => {
    let gargaloAlvo: RotinaGargalo | { id: string } = g!;
    if (novoGargalo.trim()) {
      gargaloAlvo = await abrirGargalo.mutateAsync({
        negocioId: negocio.id,
        descricao: novoGargalo.trim(),
        gargaloAtualId: g!.id,
        comoResolvido: true,
      });
    }
    if (novaAcaoDesc.trim()) {
      await definirAcao.mutateAsync({
        gargaloId: gargaloAlvo.id,
        descricao: novaAcaoDesc.trim(),
        dono: dono.trim() || "Ellen",
        prazo: prazo || null,
        acaoAtivaId: gargaloAlvo.id === g!.id ? (a?.id ?? null) : null,
      });
    } else if (gargaloAlvo.id === g!.id && a) {
      await atualizarAcao.mutateAsync({ id: a.id, dono: dono.trim() || "Ellen", prazo: prazo || null });
    }
    setNovoGargalo("");
    setNovaAcaoDesc("");
  };

  return (
    <Card className="p-4" style={{ borderLeft: `4px solid ${negocio.cor}` }}>
      <div className="mb-1.5 flex items-center gap-2">
        <h3 className="text-sm font-semibold">{negocio.nome}</h3>
        {g && dias >= 21 && <Badge variant="outline" className="border-destructive text-destructive">{dias} dias aberto</Badge>}
      </div>

      {g ? (
        <>
          <p className="text-sm"><strong>Gargalo atual</strong> (aberto em {fmtBR(g.aberto_em)}): {g.descricao}</p>
          {a ? (
            <>
              <p className="mt-1 text-xs text-muted-foreground">Ação: {a.descricao} — dono: {a.dono}, prazo: {fmtBR(a.prazo)}</p>
              <PassosChecklist acaoId={a.id} passos={a.passos} />
            </>
          ) : (
            <p className="mt-1 text-sm text-muted-foreground">Sem ação definida para este gargalo.</p>
          )}
          <Collapsible className="mt-2">
            <CollapsibleTrigger asChild>
              <Button type="button" size="sm" variant="outline">Trocar gargalo / ação</Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2.5 flex flex-col gap-2.5">
              <p className="rounded-md border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-xs text-amber-700 dark:text-amber-400">
                Só existe um gargalo ativo por negócio. Preencher este campo <strong>arquiva automaticamente</strong> o gargalo atual e abre o novo.
              </p>
              <Field label="Novo gargalo">
                <Input value={novoGargalo} onChange={(e) => setNovoGargalo(e.target.value)} placeholder="Deixe em branco para manter o atual" />
              </Field>
              <Field label="Ação única">
                <Input value={novaAcaoDesc} onChange={(e) => setNovaAcaoDesc(e.target.value)} placeholder="Frase objetiva, com verbo" />
              </Field>
              <div className="flex gap-2.5">
                <Field label="Dono" className="flex-1"><Input value={dono} onChange={(e) => setDono(e.target.value)} /></Field>
                <Field label="Prazo" className="flex-1"><Input type="date" value={prazo ?? ""} onChange={(e) => setPrazo(e.target.value)} /></Field>
              </div>
              <Button type="button" size="sm" onClick={handleTrocar}>Salvar</Button>
            </CollapsibleContent>
          </Collapsible>
        </>
      ) : (
        <div className="flex flex-col gap-2.5">
          <Field label="Abrir novo gargalo">
            <Input value={novoGargalo} onChange={(e) => setNovoGargalo(e.target.value)} placeholder="Qual é a única restrição agora?" />
          </Field>
          <Field label="Ação única">
            <Input value={novaAcaoDesc} onChange={(e) => setNovaAcaoDesc(e.target.value)} placeholder="Frase objetiva, com verbo" />
          </Field>
          <Button type="button" size="sm" className="self-start" onClick={handleAbrirNovo} disabled={!novoGargalo.trim()}>Abrir gargalo</Button>
        </div>
      )}
    </Card>
  );
}

function Fechamento({ estado }: { estado: RotinaEstado }) {
  const hoje = hojeIso();
  const ini = inicioSemana(hoje);
  const fim = fimSemana(hoje);
  const cota = negociosComCota(estado);
  const semAtual = estado.semanas.find((s) => s.inicio === ini);
  const [obs, setObs] = useState(semAtual?.observacoes ?? "");
  const fecharSemana = useFecharSemana();

  const parado: string[] = [];
  estado.acoes.forEach((a: RotinaAcaoComPassos) => {
    if (!a.concluida_em && a.prazo && a.prazo < hoje) {
      const g = estado.gargalos.find((gg) => gg.id === a.gargalo_id);
      const n = g ? estado.negocios.find((x) => x.id === g.negocio_id) : null;
      parado.push(`${n ? n.nome : "?"}: ${a.descricao} (prazo era ${fmtBR(a.prazo)})`);
    }
  });
  const radarPendente = (estado.radar ?? []).filter((r) => !r.concluido_em);

  return (
    <Card className="p-4">
      <h2 className="mb-3 text-base font-semibold">Sexta — fechamento da semana</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Negócio</TableHead>
            <TableHead>Horas</TableHead>
            <TableHead>Alvo</TableHead>
            <TableHead>Real</TableHead>
            <TableHead>Desvio</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {cota.map((n) => {
            const horas = horasNoIntervalo(estado, n.id, ini, fim);
            const real = realPct(estado, n.id, ini, fim);
            const desvio = real - (n.atencao_alvo_pct ?? 0);
            return (
              <TableRow key={n.id}>
                <TableCell className="flex items-center gap-1.5"><span className="size-2 rounded-full" style={{ background: n.cor }} />{n.nome}</TableCell>
                <TableCell>{horas.toFixed(2)}h</TableCell>
                <TableCell>{n.atencao_alvo_pct}%</TableCell>
                <TableCell>{real.toFixed(0)}%</TableCell>
                <TableCell className={desvio < -5 ? "text-destructive" : ""}>{desvio > 0 ? "+" : ""}{desvio.toFixed(0)}pp</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>

      {parado.length > 0 && (
        <div className="mt-3 rounded-md border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400">
          <strong>Ficou parado:</strong>
          <ul className="ml-4 mt-1 list-disc">{parado.map((p, i) => <li key={i}>{p}</li>)}</ul>
        </div>
      )}
      {radarPendente.length > 0 && (
        <div className="mt-3 rounded-md border border-amber-400/40 bg-amber-400/10 px-3 py-2 text-sm text-amber-700 dark:text-amber-400">
          <strong>{radarPendente.length} item(ns) no radar ainda em aberto:</strong>
          <ul className="ml-4 mt-1 list-disc">{radarPendente.map((r) => <li key={r.id}>{r.texto}</li>)}</ul>
        </div>
      )}

      <Field label="Observações da semana" className="mt-3">
        <Textarea value={obs} onChange={(e) => setObs(e.target.value)} rows={3} />
      </Field>
      <div className="mt-2 flex items-center gap-2">
        <Button
          type="button"
          onClick={() => fecharSemana.mutate({ id: semAtual?.id, inicio: ini, observacoes: obs })}
        >
          {semAtual?.fechada ? "Semana fechada — atualizar" : "Fechar semana"}
        </Button>
        {semAtual?.fechada && <Badge variant="outline">fechada</Badge>}
      </div>
    </Card>
  );
}

export function AbaSemana({ estado }: { estado: RotinaEstado }) {
  const negocios = negociosAtivos(estado);
  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="mb-1 text-base font-semibold">Segunda — gargalo e ação única</h2>
        <p className="mb-3 text-xs text-muted-foreground">Um gargalo ativo por negócio. Uma única próxima ação por gargalo.</p>
        <div className="flex flex-col gap-3">
          {negocios.map((n) => <CardNegocio key={n.id} estado={estado} negocio={n} />)}
        </div>
      </div>
      <Fechamento estado={estado} />
    </div>
  );
}
