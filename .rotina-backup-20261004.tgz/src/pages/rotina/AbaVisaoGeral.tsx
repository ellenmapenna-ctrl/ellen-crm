import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { PassosChecklist } from "@/components/rotina/PassosChecklist";
import { acaoAtivaDoGargalo, diasEntre, gargaloAberto, negociosAtivos } from "@/lib/rotina";
import { hojeIso } from "@/lib/sitplan";
import { useConcluirAcao, useConcluirRadar, useRemoverRadar } from "@/hooks/useRotina";
import type { RotinaEstado } from "@/lib/types";

export function AbaVisaoGeral({ estado }: { estado: RotinaEstado }) {
  const hoje = hojeIso();
  const negocios = negociosAtivos(estado);
  const abertos = (estado.radar ?? []).filter((r) => !r.concluido_em);
  const radarGeral = abertos.filter((r) => !r.negocio_id);

  const concluirAcao = useConcluirAcao();
  const concluirRadar = useConcluirRadar();
  const removerRadar = useRemoverRadar();

  const radarMini = (itens: typeof abertos) => (
    <div className="flex flex-col divide-y">
      {itens.map((r) => (
        <div key={r.id} className="flex items-center gap-2 py-1.5">
          <Checkbox checked={false} onCheckedChange={() => concluirRadar.mutate(r.id)} aria-label="Concluir item do radar" />
          <span className="flex-1 text-sm">{r.texto}</span>
          <button type="button" className="text-muted-foreground hover:text-destructive" onClick={() => removerRadar.mutate(r.id)} aria-label="Remover item">×</button>
        </div>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm text-muted-foreground">
        Todo gargalo, ação, passo e item do radar dos negócios, lado a lado. O compromisso da semana continua sendo 1 gargalo · 1 ação, definido na aba Semana.
      </p>
      <div className="grid grid-cols-1 gap-3.5 lg:grid-cols-2">
        {negocios.map((n) => {
          const g = gargaloAberto(estado, n.id);
          const radarNegocio = abertos.filter((r) => r.negocio_id === n.id);
          return (
            <Card key={n.id} className="p-4" style={{ borderLeft: `4px solid ${n.cor}` }}>
              <div className="mb-1.5 flex items-center gap-1.5">
                <span className="size-2.5 shrink-0 rounded-full" style={{ background: n.cor }} />
                <h3 className="text-sm font-semibold">{n.nome}</h3>
              </div>
              {g ? (
                <>
                  <div className="text-sm">
                    <strong>Gargalo:</strong> {g.descricao}
                    {diasEntre(g.aberto_em, hoje) >= 21 && (
                      <Badge variant="outline" className="ml-1.5 border-destructive text-destructive">{diasEntre(g.aberto_em, hoje)} dias aberto</Badge>
                    )}
                  </div>
                  {(() => {
                    const a = acaoAtivaDoGargalo(estado, g.id);
                    if (!a) return <p className="mt-1.5 text-sm text-muted-foreground">Sem ação definida.</p>;
                    return (
                      <div className="mt-2">
                        <label className="flex cursor-pointer items-start gap-1.5 text-sm">
                          <Checkbox className="mt-0.5" checked={false} onCheckedChange={() => concluirAcao.mutate(a.id)} />
                          <span>{a.descricao}</span>
                        </label>
                        <div className="ml-5 mt-0.5 text-xs text-muted-foreground">dono: {a.dono} · prazo: {a.prazo ? new Date(a.prazo + "T00:00:00").toLocaleDateString("pt-BR") : "—"}</div>
                        <div className="ml-5"><PassosChecklist acaoId={a.id} passos={a.passos} /></div>
                      </div>
                    );
                  })()}
                </>
              ) : (
                <p className="text-sm text-muted-foreground">Sem gargalo aberto.</p>
              )}
              {radarNegocio.length > 0 && (
                <>
                  <div className="mb-1 mt-3 text-[0.7rem] font-medium uppercase tracking-wide text-muted-foreground">Radar</div>
                  {radarMini(radarNegocio)}
                </>
              )}
            </Card>
          );
        })}
        <Card className="p-4 lg:col-span-2">
          <h3 className="mb-1.5 text-sm font-semibold">Radar geral</h3>
          {radarGeral.length ? radarMini(radarGeral) : <p className="text-sm text-muted-foreground">Nada aqui.</p>}
        </Card>
      </div>
    </div>
  );
}
