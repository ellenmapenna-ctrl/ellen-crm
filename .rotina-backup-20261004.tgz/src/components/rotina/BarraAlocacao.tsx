import { Card } from "@/components/ui/card";
import { fimSemana, fmtBR, inicioSemana, negociosComCota, realPct } from "@/lib/rotina";
import { hojeIso } from "@/lib/sitplan";
import type { RotinaEstado } from "@/lib/types";

export function BarraAlocacao({ estado }: { estado: RotinaEstado }) {
  const hoje = hojeIso();
  const ini = inicioSemana(hoje);
  const fim = fimSemana(hoje);
  const negocios = negociosComCota(estado);

  if (negocios.length === 0) return null;

  return (
    <Card className="p-4">
      <h2 className="mb-1 text-base font-semibold">Alocação da semana</h2>
      <p className="mb-3 text-xs text-muted-foreground">
        Traço = alvo · barra colorida = horas reais registradas ({fmtBR(ini)}–{fmtBR(fim)})
      </p>
      <div className="flex flex-col gap-2">
        {negocios.map((n) => {
          const real = realPct(estado, n.id, ini, fim);
          const alvo = n.atencao_alvo_pct ?? 0;
          const desvio = real - alvo;
          const desvioTxt = `${desvio > 0 ? "+" : ""}${desvio.toFixed(0)}pp`;
          return (
            <div key={n.id} className="flex items-center gap-2.5 py-1">
              <div className="flex w-32 shrink-0 items-center gap-1.5 text-sm">
                <span className="size-2 shrink-0 rounded-full" style={{ background: n.cor }} />
                {n.nome}
              </div>
              <div className="relative h-3.5 flex-1 overflow-hidden rounded-full border bg-muted">
                <div
                  className="absolute inset-y-0 left-0 rounded-full transition-all"
                  style={{ width: `${Math.min(100, real)}%`, background: n.cor }}
                />
                <div className="absolute inset-y-[-2px] w-0.5 bg-foreground" style={{ left: `${Math.min(100, alvo)}%` }} />
              </div>
              <div className="w-44 shrink-0 text-right text-xs text-muted-foreground">
                alvo {alvo}% · real {real.toFixed(0)}% ·{" "}
                <span className={desvio < -5 ? "font-semibold text-destructive" : ""}>{desvioTxt}</span>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
