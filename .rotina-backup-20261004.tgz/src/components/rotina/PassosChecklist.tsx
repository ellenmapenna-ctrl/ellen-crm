import { useState } from "react";
import { X } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useAdicionarPasso, useRemoverPasso, useTogglePasso } from "@/hooks/useRotina";
import type { RotinaPasso } from "@/lib/types";

interface Props {
  acaoId: string;
  passos: RotinaPasso[];
}

export function PassosChecklist({ acaoId, passos }: Props) {
  const [novo, setNovo] = useState("");
  const adicionar = useAdicionarPasso();
  const toggle = useTogglePasso();
  const remover = useRemoverPasso();
  const feitos = passos.filter((p) => p.concluido_em).length;

  const handleAdicionar = () => {
    const texto = novo.trim();
    if (!texto) return;
    adicionar.mutate({ acaoId, descricao: texto });
    setNovo("");
  };

  return (
    <div className="mt-2 flex flex-col gap-1">
      {passos.map((p) => (
        <div key={p.id} className="flex items-center gap-2 py-0.5 text-sm">
          <Checkbox
            checked={!!p.concluido_em}
            onCheckedChange={(v) => toggle.mutate({ id: p.id, concluido: !!v })}
          />
          <span className={cn("flex-1", p.concluido_em && "text-muted-foreground line-through")}>{p.descricao}</span>
          <button
            type="button"
            className="text-muted-foreground hover:text-destructive"
            onClick={() => remover.mutate(p.id)}
            aria-label="Remover passo"
          >
            <X className="size-3.5" />
          </button>
        </div>
      ))}
      {passos.length > 0 && (
        <span className="text-xs text-muted-foreground">{feitos}/{passos.length} concluídos</span>
      )}
      <div className="mt-1 flex gap-1.5">
        <Input
          value={novo}
          onChange={(e) => setNovo(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleAdicionar(); } }}
          placeholder="Adicionar passo..."
          className="h-8 text-xs"
        />
        <Button type="button" size="sm" variant="outline" className="h-8 shrink-0 px-2" onClick={handleAdicionar}>+</Button>
      </div>
    </div>
  );
}
