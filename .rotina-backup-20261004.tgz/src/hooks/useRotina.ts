import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { qk } from "@/lib/query-keys";
import { hojeIso } from "@/lib/sitplan";
import { uid } from "@/lib/rotina";
import type {
  RotinaAcaoComPassos,
  RotinaEstado,
  RotinaNegocioUpdate,
} from "@/lib/types";

export function useRotinaEstado() {
  return useQuery({
    queryKey: qk.rotina.all,
    queryFn: async (): Promise<RotinaEstado> => {
      const [negocios, gargalos, acoes, passos, registros, notas, semanas, radar] = await Promise.all([
        supabase.from("rotina_negocios").select("*").order("created_at", { ascending: true }),
        supabase.from("rotina_gargalos").select("*").order("aberto_em", { ascending: true }),
        supabase.from("rotina_acoes").select("*").order("created_at", { ascending: true }),
        supabase.from("rotina_passos").select("*").order("created_at", { ascending: true }),
        supabase.from("rotina_registros").select("*"),
        supabase.from("rotina_notas").select("*"),
        supabase.from("rotina_semanas").select("*"),
        supabase.from("rotina_radar").select("*"),
      ]);
      for (const r of [negocios, gargalos, acoes, passos, registros, notas, semanas, radar]) {
        if (r.error) throw r.error;
      }
      const acoesComPassos: RotinaAcaoComPassos[] = (acoes.data ?? []).map((a) => ({
        ...a,
        passos: (passos.data ?? []).filter((p) => p.acao_id === a.id),
      }));
      return {
        negocios: negocios.data ?? [],
        gargalos: gargalos.data ?? [],
        acoes: acoesComPassos,
        registros: registros.data ?? [],
        notas: notas.data ?? [],
        semanas: semanas.data ?? [],
        radar: radar.data ?? [],
      };
    },
  });
}

function useInvalidarRotina() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: qk.rotina.all });
}

export function useAtualizarNegocio() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ id, campos }: { id: string; campos: RotinaNegocioUpdate }) => {
      const { error } = await supabase.from("rotina_negocios").update(campos).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

/** Arquiva o gargalo aberto atual do negócio (se existir) e abre um novo. */
export function useAbrirGargalo() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({
      negocioId,
      descricao,
      gargaloAtualId,
      comoResolvido,
    }: {
      negocioId: string;
      descricao: string;
      gargaloAtualId?: string | null;
      comoResolvido?: boolean;
    }) => {
      if (gargaloAtualId) {
        const { error: e1 } = await supabase
          .from("rotina_gargalos")
          .update({ status: comoResolvido ? "resolvido" : "arquivado", resolvido_em: hojeIso() })
          .eq("id", gargaloAtualId);
        if (e1) throw e1;
      }
      const novo = { id: uid("g"), negocio_id: negocioId, descricao, aberto_em: hojeIso(), status: "aberto" };
      const { data, error } = await supabase.from("rotina_gargalos").insert(novo).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: invalidar,
  });
}

/** Conclui a ação ativa do gargalo (se existir) e define uma nova. */
export function useDefinirAcao() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({
      gargaloId,
      descricao,
      dono,
      prazo,
      acaoAtivaId,
    }: {
      gargaloId: string;
      descricao: string;
      dono?: string;
      prazo?: string | null;
      acaoAtivaId?: string | null;
    }) => {
      if (acaoAtivaId) {
        const { error: e1 } = await supabase
          .from("rotina_acoes")
          .update({ concluida_em: hojeIso() })
          .eq("id", acaoAtivaId);
        if (e1) throw e1;
      }
      const nova = { id: uid("a"), gargalo_id: gargaloId, descricao, dono: dono || "Ellen", prazo: prazo || null };
      const { data, error } = await supabase.from("rotina_acoes").insert(nova).select().single();
      if (error) throw error;
      return data;
    },
    onSuccess: invalidar,
  });
}

/** Atualiza dono/prazo da ação ativa sem trocar a descrição. */
export function useAtualizarAcao() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ id, dono, prazo }: { id: string; dono: string; prazo: string | null }) => {
      const { error } = await supabase.from("rotina_acoes").update({ dono, prazo }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useConcluirAcao() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("rotina_acoes").update({ concluida_em: hojeIso() }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useAdicionarPasso() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ acaoId, descricao }: { acaoId: string; descricao: string }) => {
      const { error } = await supabase.from("rotina_passos").insert({ id: uid("p"), acao_id: acaoId, descricao });
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useTogglePasso() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ id, concluido }: { id: string; concluido: boolean }) => {
      const { error } = await supabase
        .from("rotina_passos")
        .update({ concluido_em: concluido ? hojeIso() : null })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useRemoverPasso() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("rotina_passos").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

/** Registra (ou apaga, se horas for null) as horas de um negócio num dia. */
export function useRegistrarHoras() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({
      negocioId,
      data,
      horas,
      registroExistenteId,
    }: {
      negocioId: string;
      data: string;
      horas: number | null;
      registroExistenteId?: string | null;
    }) => {
      if (horas === null) {
        if (registroExistenteId) {
          const { error } = await supabase.from("rotina_registros").delete().eq("id", registroExistenteId);
          if (error) throw error;
        }
        return;
      }
      if (registroExistenteId) {
        const { error } = await supabase.from("rotina_registros").update({ horas }).eq("id", registroExistenteId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("rotina_registros").insert({ id: uid("r"), negocio_id: negocioId, data, horas });
        if (error) throw error;
      }
    },
    onSuccess: invalidar,
  });
}

export function useAdicionarNota() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async (texto: string) => {
      const { error } = await supabase.from("rotina_notas").insert({ id: uid("n"), data: hojeIso(), texto });
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useFecharSemana() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ id, inicio, observacoes }: { id?: string | null; inicio: string; observacoes: string }) => {
      if (id) {
        const { error } = await supabase.from("rotina_semanas").update({ fechada: true, observacoes }).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("rotina_semanas").insert({ id: uid("s"), inicio, fechada: true, observacoes });
        if (error) throw error;
      }
    },
    onSuccess: invalidar,
  });
}

export function useAdicionarRadar() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async ({ texto, negocioId }: { texto: string; negocioId: string | null }) => {
      const { error } = await supabase
        .from("rotina_radar")
        .insert({ id: uid("rd"), texto, negocio_id: negocioId, criado_em: hojeIso() });
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useConcluirRadar() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("rotina_radar").update({ concluido_em: hojeIso() }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}

export function useRemoverRadar() {
  const invalidar = useInvalidarRotina();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("rotina_radar").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidar,
  });
}
