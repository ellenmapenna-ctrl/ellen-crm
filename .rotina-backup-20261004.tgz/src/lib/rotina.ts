import type { RotinaAcaoComPassos, RotinaEstado, RotinaGargalo, RotinaNegocio } from "@/lib/types";
import { hojeIso } from "@/lib/sitplan";

// Portado do app standalone "Painel de Atenção" (/Users/adm/Painel-Atencao) —
// gestão por gargalos (teoria das restrições): um gargalo aberto por negócio,
// uma ação única ativa por gargalo.

export function uid(prefixo: string): string {
  return `${prefixo}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

/* ---------- datas ---------- */
export function parseDataIso(s: string): Date {
  const [ano, mes, dia] = s.split("-").map(Number);
  return new Date(ano, mes - 1, dia);
}
export function paraDataIso(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
export function addDias(s: string, n: number): string {
  const d = parseDataIso(s);
  d.setDate(d.getDate() + n);
  return paraDataIso(d);
}
export function inicioSemana(s: string): string {
  const d = parseDataIso(s);
  const diaSemana = d.getDay();
  const diff = diaSemana === 0 ? -6 : 1 - diaSemana;
  d.setDate(d.getDate() + diff);
  return paraDataIso(d);
}
export function fimSemana(s: string): string {
  return addDias(inicioSemana(s), 6);
}
export function diasEntre(a: string, b: string): number {
  return Math.round((parseDataIso(b).getTime() - parseDataIso(a).getTime()) / 86400000);
}
export function fmtBR(s: string | null | undefined): string {
  if (!s) return "—";
  const [, mes, dia] = s.split("-");
  return `${dia}/${mes}`;
}

/* ---------- consultas sobre o estado ---------- */
export function negociosAtivos(estado: RotinaEstado): RotinaNegocio[] {
  return estado.negocios.filter((n) => n.ativo);
}
export function negociosComCota(estado: RotinaEstado): RotinaNegocio[] {
  return negociosAtivos(estado).filter((n) => n.atencao_alvo_pct !== null);
}
export function negocioPorId(estado: RotinaEstado, id: string): RotinaNegocio | undefined {
  return estado.negocios.find((n) => n.id === id);
}
export function gargaloAberto(estado: RotinaEstado, negocioId: string): RotinaGargalo | undefined {
  return estado.gargalos.find((g) => g.negocio_id === negocioId && g.status === "aberto");
}
export function acaoAtivaDoGargalo(estado: RotinaEstado, gargaloId: string): RotinaAcaoComPassos | undefined {
  const lista = estado.acoes.filter((a) => a.gargalo_id === gargaloId && !a.concluida_em);
  return lista.length ? lista[lista.length - 1] : undefined;
}
export function horasNoIntervalo(estado: RotinaEstado, negocioId: string, ini: string, fim: string): number {
  return estado.registros
    .filter((r) => r.negocio_id === negocioId && r.data >= ini && r.data <= fim)
    .reduce((s, r) => s + (Number(r.horas) || 0), 0);
}
export function totalHorasIntervalo(estado: RotinaEstado, ini: string, fim: string): number {
  return estado.registros
    .filter((r) => r.data >= ini && r.data <= fim)
    .reduce((s, r) => s + (Number(r.horas) || 0), 0);
}
export function realPct(estado: RotinaEstado, negocioId: string, ini: string, fim: string): number {
  const total = totalHorasIntervalo(estado, ini, fim);
  if (total <= 0) return 0;
  return (horasNoIntervalo(estado, negocioId, ini, fim) / total) * 100;
}

/* ---------- matriz de portfólio ---------- */
export type Quadrante = "motor" | "armadilha" | "piloto" | "dreno";
export function quadranteDe(n: RotinaNegocio): Quadrante {
  if (n.retorno === "alto" && n.dependencia === "baixa") return "motor";
  if (n.retorno === "alto" && n.dependencia === "alta") return "armadilha";
  if (n.retorno === "baixo" && n.dependencia === "baixa") return "piloto";
  return "dreno";
}
export const QUADRANTES: Record<Quadrante, { titulo: string; desc: string }> = {
  motor: { titulo: "Motor", desc: "Alto retorno · roda sem mim — investir e escalar" },
  armadilha: { titulo: "Armadilha dourada", desc: "Alto retorno · depende de mim — delegar antes de crescer" },
  piloto: { titulo: "Piloto automático", desc: "Baixo retorno · roda sem mim — revisar 1× por mês" },
  dreno: { titulo: "Dreno", desc: "Baixo retorno · depende de mim — cortar, vender ou fechar" },
};

/* ---------- avisos globais ---------- */
export interface RotinaAviso {
  tipo: "critico" | "aviso";
  texto: string;
}
export function calcularAvisos(estado: RotinaEstado): RotinaAviso[] {
  const avisos: RotinaAviso[] = [];
  const hoje = hojeIso();
  estado.gargalos.forEach((g) => {
    if (g.status === "aberto") {
      const dias = diasEntre(g.aberto_em, hoje);
      if (dias >= 21) {
        const n = negocioPorId(estado, g.negocio_id);
        avisos.push({ tipo: "critico", texto: `${n ? n.nome : g.negocio_id}: gargalo aberto há ${dias} dias. Gargalo antigo geralmente é gargalo mal diagnosticado.` });
      }
    }
  });
  const soma = negociosComCota(estado).reduce((s, n) => s + (n.atencao_alvo_pct || 0), 0);
  if (soma !== 100) {
    avisos.push({ tipo: "aviso", texto: `A soma das atenções-alvo está em ${soma}%, não 100%. Ajuste em Portfólio.` });
  }
  return avisos;
}
